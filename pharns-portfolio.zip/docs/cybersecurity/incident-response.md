# 🛡 Incident Response Workflow

**Objective:** Simulate incident management with TheHive + Cortex.

**Tools:** TheHive, Cortex

**Skills:** Triage, IOC enrichment, case workflow, documentation

**Artifacts:** Link to demo cases/screenshots.

**Summary:** What I automated, how I handled evidence, and lessons.
