# 🔍 Vulnerability Assessment

**Objective:** Identify, prioritize, and report vulnerabilities.

**Tools:** Nessus

**Skills:** Vulnerability scanning, triage, reporting

**Artifacts:** Link to report PDFs or markdown write-ups.

**Summary:** Scope, methodology, and results with key remediation recommendations.
