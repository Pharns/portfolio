# 📜 Certifications

Badges + verification links (same table from your portfolio README). Keep this page tidy and current.
