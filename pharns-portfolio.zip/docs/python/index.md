# 🐍 Python — Overview

This section bridges **Python** with my cybersecurity work.

- **100 Days of Python (live):** Progress and daily exercises.
- **Projects (live):** Independent projects (automation, data viz, tooling).

> I use Python for scripting, parsing logs, and building small tools that accelerate security work.
