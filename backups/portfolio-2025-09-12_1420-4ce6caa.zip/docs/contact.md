# 🤝 Contact

- **LinkedIn:** [https://linkedin.com/in/pharns](https://linkedin.com/in/pharns)
- **GitHub:** [https://github.com/Pharns](https://github.com/Pharns)

